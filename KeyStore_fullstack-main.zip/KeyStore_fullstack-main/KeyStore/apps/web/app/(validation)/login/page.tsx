export default function LoginPage() {
  return <div>Login page</div>;
}
