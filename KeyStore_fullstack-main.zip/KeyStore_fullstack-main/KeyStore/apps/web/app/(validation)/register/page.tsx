export default function RegisterPage() {
  return <div>register page</div>;
}
