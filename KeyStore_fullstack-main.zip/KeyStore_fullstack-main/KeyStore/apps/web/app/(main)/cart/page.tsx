export default function Cart() {
  return <div>cart page</div>;
}
