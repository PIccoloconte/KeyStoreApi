export default function Checkout() {
  return <div>checkout page</div>;
}
